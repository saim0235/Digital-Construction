import React from 'react'
import SignupUI from '../components/Signup'

const signupPage = () => {
  return (
    <SignupUI />
  )
}

export default signupPage