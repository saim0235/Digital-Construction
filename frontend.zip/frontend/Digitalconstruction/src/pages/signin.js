import React from 'react'
import LoginUi from '../components/Signin'

const signinPage = () => {
  return (
    <div>
      <LoginUi/>
    </div>
  )
}

export default signinPage