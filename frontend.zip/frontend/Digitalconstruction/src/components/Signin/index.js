import './LoginUi.css';
import {  Nav, NavContainer, NavLogo } from '../Navbar/NavbarElement'
import { Link } from 'react-router-dom';


function LoginUi() {

  return (
    <>
    <Nav>
    <NavContainer>
    <NavLogo to='/'>Digital Construction</NavLogo>
    </NavContainer>
    </Nav>
    <div className="Auth-form-container">
      <div class="signin-container">
        <form>
          <h1> Login </h1>
          <input type="text" placeholder="Email" />
          <input type="password" placeholder="Password" />
          <Link to="/dashboard"><button type="submit">Log in</button></Link>
          <div className='cred'>
          Create an account ? <Link to="/signup" id='reg'> Register </Link>
          </div>
        </form>
      </div>
    </div>
    </>

  );
}

export default LoginUi;