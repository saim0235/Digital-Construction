import React from 'react'
import I1 from '../../images/card1.svg'
import I2 from '../../images/card2.svg'
import I3 from '../../images/card3.svg'
import { ServicesContainer, ServicesH1 ,  ServicesWrapper , ServicesCard, 
ServicesIcon, ServicesH2, ServicesP} from './ServicesElements'

const Services = () => {
  return (
    <ServicesContainer id='services'>
        <ServicesH1>Our Services</ServicesH1>
        <ServicesWrapper>
            <ServicesCard>
                <ServicesIcon src={I1}/>
                <ServicesH2>Construction Designs</ServicesH2>
                <ServicesP>Architects and Designer create designs of your choice  </ServicesP>
            </ServicesCard>
            <ServicesCard>
                <ServicesIcon src={I2}/>
                <ServicesH2>Construction Material</ServicesH2>
                <ServicesP>You can purchase construction material from different companies</ServicesP>
            </ServicesCard>
            <ServicesCard>
                <ServicesIcon src={I3}/>
                <ServicesH2>Provide Your Services</ServicesH2>
                <ServicesP>you can work as builder, architect and retailer compnay</ServicesP>
            </ServicesCard>
        </ServicesWrapper>
    </ServicesContainer>
  )
}

export default Services