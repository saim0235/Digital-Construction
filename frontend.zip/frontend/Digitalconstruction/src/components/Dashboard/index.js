import React from 'react'
// import { BrowserRouter, Routes, Route  } from 'react-router-dom'
// import About from '../Dashboard/pages/About'
// import Analytics from '../Dashboard/pages/Analytics'
// import Product from '../Dashboard/pages/Product'
// import ProductList from '../Dashboard/pages/ProductList'
import Sidebar from '../Dashboard/comps/Sidebar'
import './dash.css'


const DashboardX = () => {
  return (

    <Sidebar/>
    //   <BrowserRouter>
    //   <Sidebar/>
    //   <Routes>
    //   <Route path='/dashboard/' element={<About/>}></Route>
    //   <Route path='/about' element={<About/>}></Route>
    //    <Route path='/analytics' element={<Analytics/>}></Route>
    //    <Route path='/product' element={<Product/>}></Route>
    //    <Route path='/productlist' element={<ProductList/>}></Route>
    //  </Routes>
    //  <Sidebar/>
    //  </BrowserRouter>
    
  )
}

export default DashboardX