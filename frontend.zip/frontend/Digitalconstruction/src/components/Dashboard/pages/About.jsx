import React from 'react'

const About = () => {
  return (
    <div style={{fontsize : '40px'}}>About</div>
  )
}

export default About