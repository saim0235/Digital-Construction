import React from 'react'
import { FaChartBar,FaBars, FaShoppingBag, FaThList, FaUserAlt } from 'react-icons/fa'
import { NavLink } from 'react-router-dom'
const Sidebar = ({children}) => {
    const menuItem=[
    {
        path:'/dashboard/',
        name:'About',
        icon:<FaUserAlt/>
    },
    {
        path:'/dashboard/',
        name:'Analytics',
        icon:<FaChartBar/>
    },
    {
        path:'/dashboard/',
        name:'Product',
        icon:<FaShoppingBag/>
    },
    {
        path:'/dashboard/',
        name:'Product List',
        icon:<FaThList/>
    },

]
  return (
    <div className='container'>
        <div className='sidebar'>
            <div className='top_section'>
                <h1 className='logo'>Company</h1>
                <div className='bars'>
                    <FaBars/>
                </div>
            </div>
            {
            menuItem.map((item,index)=>(
                <NavLink to={item.path} key={index} 
                className='linkt' activeclassName='activet'>
                    <div className='icon'>
                        {item.icon}
                    </div>
                    <div className='item_text'>
                        {item.name}
                    </div>
                </NavLink>
            ))
        }
        </div>
       <div className='main'>{children}</div>
    </div>
  )
}

export default Sidebar