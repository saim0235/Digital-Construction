import img2 from '../../images/2.svg'
import img3 from '../../images/3.svg'
import img5 from '../../images/5.svg'

export const homeObjOne = {
    id:'about',
    lightbg: false,
    lightText : true,
    lightTextDesc : true,
    topLine : 'Premium Deal',
    headline : 'View Construction Designs',
    description : 'Get access to our exclusive app that allows you to view unique designs and make it according to your requirements',
    buttonlabel: 'Get started',
    imgStart: false,
    alt: 'House',
    dark : true,
    primary : true,
    darkText : false,
    img: img2
}

export const homeObjTwo = {
    id:'discover',
    lightbg: true,
    lightText : false,
    lightTextDesc : false,
    topLine : 'Discover',
    headline : 'Interact with your workers',
    description : 'Meet your clients, Contractors, Architects, Designers and Companies',
    buttonlabel: 'Get started',
    imgStart: true,
    alt: 'PeopleViewer',
    dark : false,
    primary : false,
    darkText : true,
    img: img3
}

export const homeObjThree = {
    id:'signup',
    lightbg: true,
    lightText : false,
    lightTextDesc : false,
    topLine : 'Register Now',
    headline : 'Creating an account is extremely easy',
    description : "Get everything set up and ready in under 10 minutes. All you need to do is add your information and you're ready to go.",
    buttonlabel: 'Register Now',
    imgStart: false,
    alt: 'PeopleViewer',
    dark : false,
    primary : false,
    darkText : true,
    img: img5
}


