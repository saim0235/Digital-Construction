import React from 'react'
import {  Nav, NavContainer, NavLogo } from '../Navbar/NavbarElement'
import { Link } from 'react-router-dom';
import './Signup.css';

const SignupUI = () => {
    return (
        <>
    <Nav>
    <NavContainer>
    <NavLogo to='/'>Digital Construction</NavLogo>
    </NavContainer>
    </Nav>
    <div className="Auth-form-container">
      <div class="signin-container">
        <form>
          <h1> Sign Up </h1>
          <input type="text" placeholder="Name" />
          <input type="text" placeholder="PhoneNo" />
          <input type="text" placeholder="Email" />
          <input type="password" placeholder="Password" />
          <Link to="/signin"><button type="submit">Register</button></Link>
          <div className='cred'>
          Already Have an Account ? <Link to="/signin" id='reg'> Sign In </Link>
          </div>

        </form>
      </div>
    </div>
    </>
    )
}

export default SignupUI